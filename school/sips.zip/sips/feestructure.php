<?php
include("navigation.php");
?>

<div class="container wow fadeInUp">
    <div class="row">
        <div class="col-md-12">
            <h3 class="section-title">Fee Structure</h3>
            <div class="section-title-divider"></div>
        </div>
    </div>
</div>

<div id="container">


    <section id="content" class="two-column with-right-sidebar" style="color:black;">

        <h2 style="color:#2874A6; padding-left:30px;">Information Regarding Fee</h2>
        <div style="color:black; padding-left:30px;">
            <p>The school charges afforadable and equal fee from each student commensurate to the class. The Fee is finalized by the Managing Committee as per the guidelines of the Fee Regulatory Committee of the Government/Board. </p>

        </div>

    </section>

    <aside class="sidebar big-sidebar right-sidebar">


        <ul>	
            <li class="color-bg">
                <h4 style="font-size:25px;">Admission Information</h4>
                <ul class="blocklist" style="font-size:15px;">
                    <li><a class="" href="admission.php">Amission Cell</a></li>
                    <li><a class="" href="index.html">Online registration</a></li>
                    <li><a class="" href="admissionprocess.php">Admission Process</a></li>
                    <li><a class="" href="guidelines.php">Criteria/Guidelines</a></li>
                    <li><a class="" href="index.html">Admission Form pdf</a></li>	
                    <li><a class="" href="reqdocuments.php">Documents Required </a></li>
                    <li><a class="selected" href="feestructure.php">Fee Structure</a></li>	
                    </aside>
                    <div class="clear"></div>
                    <br><br>
                    </div>





                    <!--
                  
                  <div class="container about-container wow fadeInUp">
                <div class="row">
                            <div class="col-md-12">
                            <h3 style="color:#2874A6">Information Regarding Fee</h3>
                            <p style="color:black;">The school charges afforadable and equal fee from each student commensurate to the class. The Fee is finalized by the Managing Committee as per the guidelines of the Fee Regulatory Committee of the Government/Board. </p>
                          <br><br><br><br>
                            </div>
                            
          
                          
                  <table class="table table-bordered" style="color:black;">
              <thead style="background-color:#2874A6; color:white;">
                <tr>
                  <th>Class</th>
                  <th>1st Instalment</th>
                  <th>2nd Instalment</th>
                          <th>Total</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>L.K.G.</td>
                  <td>7800</td>
                  <td>5200</td>
                          <td>13000</td>
                </tr>
                <tr>
                  <td>U.K.G</td>
                  <td>8100</td>
                  <td>5400</td>
                          <td>13500</td>		
                </tr>
                    <tr>
                  <td>I</td>
                  <td>8400</td>
                  <td>5600</td>
                          <td>14000</td>		
                </tr>
                    <tr>
                  <td>II</td>
                  <td>8700</td>
                  <td>5800</td>
                          <td>14500</td>		
                </tr>
                    <tr>
                  <td>III</td>
                  <td>9000</td>
                  <td>6000</td>
                          <td>15000</td>		
                </tr>
                    <tr>
                  <td>IV</td>
                  <td>9300</td>
                  <td>6200</td>
                          <td>15500</td>		
                </tr>
                    <tr>
                  <td>V</td>
                  <td>9600</td>
                  <td>6400</td>
                          <td>16000</td>		
                </tr>
                    <tr>
                  <td>VI</td>
                  <td>10500</td>
                  <td>7000</td>
                          <td>17500</td>		
                </tr>
                    <tr>
                  <td>VII</td>
                  <td>11100</td>
                  <td>7400</td>
                          <td>18500</td>		
                </tr>
                    <tr>
                  <td>VIII</td>
                  <td>11700</td>
                  <td>7800</td>
                          <td>19500</td>		
                </tr>
                    <tr>
                  <td>IX</td>
                  <td>12600</td>
                  <td>8400</td>
                          <td>21000</td>		
                </tr>
                    <tr>
                  <td>X</td>
                  <td>13800</td>
                  <td>9200</td>
                          <td>23000</td>		
                </tr>
                    <tr>
                  <td>XI</td>
                  <td>17700</td>
                  <td>11800</td>
                          <td>29500</td>
                </tr>
                      <tr>
                  <td>XII</td>
                  <td>18900</td>
                  <td>12600</td>
                          <td>31500</td>
                </tr>
              </tbody>
            </table> 
                  
                   </div>
                   </div>
                   </div>-->
                    <?php
                    include("footer.html");
                    ?>
 
