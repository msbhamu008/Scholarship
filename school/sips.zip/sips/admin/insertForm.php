
<form action="updateInsert.php" method="POST">
<div>

	  <label>Title:</label>
	  <input type="text" id="title" name="title"></input>
       <label>Description:</label>
	  <input type="text" id="desc" name="desc"></input>
	  
	  <input type="submit" value="Insert" name="insert">
</div>
</form>