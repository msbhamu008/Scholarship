<?php
include("navigation.php");
?>
<div class="container wow fadeInUp">
    <div class="row">
        <div class="col-md-12">
            <h3 class="section-title">Alumini</h3>
            <div class="section-title-divider"></div>
        </div>
    </div>
</div>
<div class="container" style="color:black;">
    <p>Dear Alumini,</p>
    <p>Sweet Remembrances,</p>
    <p>Welcome to the Alumni Network of Sunrise International Public School. We would look forward to your continued interaction and association to help improve the quality of our Academic programme, industry collaborations and various facets of our operations to ensure continuous improvements and exemplary standards of services to our present and past student community. </p>
    <br>
</div>
<?php
include("footer.html");
?>
 
