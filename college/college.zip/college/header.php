<!DOCTYPE html>
<html lang="en" dir="">

	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="" />
<meta name="author" content="" />
<meta name="robots" content="" />
<meta name="description" content="" />
<meta name="format-detection" content="telephone=no">
<!-- Favicons Icon -->
<link rel="icon" href="https://sunrisecollege.com/error-404.html" type="image/x-icon" />
<link rel="shortcut icon" type="http://educare.w3itexperts.com/xhtml/image/x-icon" href="images/favicon.png" />
<!-- Page Title Here -->
<title>Sunrise College for Higher Studies</title>
<!-- Mobile Specific -->
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link class="skin" rel="stylesheet" type="text/css" href="css/skin/skin-3.css">
<link  rel="stylesheet" type="text/css" href="css/templete.css">
<link rel="stylesheet" type="text/css" href="css/switcher.min.css">
<!-- Revolution Slider Css -->
<link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
<!-- Revolution Navigation Style -->
<link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
<!-- Google fonts -->
<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:300,400,700' rel='stylesheet'> 
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,800italic,800,700italic' rel='stylesheet' type='text/css'>

<script async src="https://www.googletagmanager.com/gtag/js?id=AW-435052853"></script> 
<script> window.dataLayer = window.dataLayer || []; 
function gtag(){dataLayer.push(arguments);
            } gtag('js', new Date()); gtag('config', 'AW-435052853'); </script>
            
  
  <script> gtag('event', 'conversion', { 'send_to': 'AW-435052853/YHp5CPCRnowYELXCuc8B', 'transaction_id': '' }); </script>
  
  <!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '460272149596472');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=460272149596472&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
</head>

	<!-- header -->
		
<body id="bg">
    
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
   
<script type="text/javascript">
  $(document).ready(function(){
    $("#myModal1").modal('show');
  });
</script>

<!-- <div id="myModal1" class="modal fade">
    <div class="modal-dialog">
     <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Sunrise College for Higher Studies</h4>
            </div>
            <div class="modal-body">
              <img src='images/Jacket2023.jpg'/>
            </div>
        </div>
    </div>
</div> -->



<div class="page-wraper"><div id="loading-area"></div>
	<!-- header END -->
	<!-- header -->
	<header class="site-header header  header-style-4 dark">
		<!-- top bar -->
		<div class="top-bar">
			<div class="container" style='width: 100%;'>
				<div class="row">
					<div class="rdx-topbar-left">
						<ul class="social-line text-center pull-right">
                                <li>
                                	<div class="apply-btn-area">
                                        <a class="apply-now-btn" style="font-size: 18px;color:#000; background-color:#ffdc5bd6;" href="OnlineAdmission.php" > Online Admission Form </a>
                                        <!--  <!-- <a class="apply-now-btn" style="font-size: 18px;color:#fff; background-color:#337ab7;" href="cuet.php" > CUET </a> --> -->
                                        <!--<a class="apply-now-btn" style="font-size: 18px;color:#fff; background-color:#337ab7;" href="images/onlinetimetable.pdf" target="_blank"> Online Time Table Schedule </a>-->
                                    </div>
                                </li> 
                        </ul>
						<ul class="social-line text-center pull-right">
							<li><a href="javascript:void(0);"><i class="fa fa-map-marker"> Salasar, Main Rd, Nechwa, Rajasthan 332026</i>  </a></li>
						</ul>
					</div>                        
					<div class="rdx-topbar-left">
						<ul class="social-line text-center pull-right">
                                <!--<li>
                                	<div class="apply-btn-area">
                                        <a class="apply-now-btn" style="font-size: 14px;color:#000; background-color:#ffdc5bd6;" href="scholarshipTest.php">Prince Civil Services Scholarship Cum Admission Test </a>
                                    </div>
                                </li>-->
                                <li>
                                	<div class="apply-btn-area">
                                        <!--<a class="apply-now-btn" style="font-size: 14px;color:#000; background-color:#ffdc5bd6;" href="admitCardLogin.php">Scholarship Cum Admission Test: Admit Card </a>-->
                                        <!--<a class="apply-now-btn" style="font-size: 14px;color:#000; background-color:#ffdc5bd6;" href="images/answerKey.pdf" target="_blank">Answer Key (16 April, 2023) </a>-->
                                        <!--<a class="apply-now-btn" style="font-size: 14px;color:#000; background-color:#ffdc5bd6;" href="scholarshipResultLogin.php" target="_blank">Scholarship Cum Admission Test: Result (07 June, 2023) </a>-->
                                    </div>
                                </li>
                        </ul>
					</div> 
					<div class="rdx-topbar-right">
						<ul class="social-line text-center pull-right">
							<li><a href="https://www.facebook.com/SUNRISEEDUHUB/" class="fa fa-facebook" target='_blank'></a></li>
							<li><a href="https://twitter.com/SUNRISEEDUHUB" class="fa fa-twitter" target='_blank'></a></li>
							<li><a href="https://www.youtube.com/channel/tpiN6rq4PSk/videos" class="fa fa-youtube" target='_blank'></a></li>
							
<!--			  <li><a href="" target="_blank"><i class="fa fa-facebook text-facebook" style="padding: 3px 3px 3px 3px;vertical-align: middle;"></i></a></li>
              <li><a href="https://twitter.com/SUNRISEEDUHUB" target="_blank"><i class="fa fa-twitter text-twitter" style="padding: 3px 3px 3px 3px;vertical-align: middle;"></i></a></li>
              <li><a href="" target="_blank"><i class="fa fa-youtube text-youtube" style="padding: 3px 3px 3px 3px;vertical-align: middle;"></i></a></li>
              <li><a href="https://www.instagram.com/princeeduhub/" target="_blank"><i class="fa fa-instagram text-insta" style="padding: 3px 3px 3px 3px;vertical-align: middle;"></i></a></li>-->
              
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- top bar END-->
		<div class="main-bar">
			<div class="container header-contant">
				<div class="row">
				    <!--<marquee behavior="scroll" scrollamount="7" width="90%">
                        <h2>
                            <a href='magazine.php' style='color: Red;font-size: 2.3rem;'>Free Current Magazine</a>
                        </h2>
                    </marquee> -->
                                    
					<div class="col-md-5">
					   <div class="logo-header" style="margin-top:5px;width:100%;">
					<a href="index.php"><img src="images/logo.png" alt="">
						</a></div>
					</div>
					<div class="col-md-4">
							<div style="text-align:center;margin-top:10px;margin-left: 20px;">
								<h6 class="text-primary"><i class="fa fa-phone"></i> Call Us</h6>
								<span>098285 12821(College) <br/>8800305186 (Entrance Exam) </span>
							</div>
						<!--	<div style="float: right;margin-top:10px;margin-right: 10px;">
								<h6 class="text-primary"><i class="fa fa-envelope-o"></i> Send us an Email</h6>
								<span> sunriseschool33@gmail.com </span>	
							</div>-->
					</div>
					<div class="col-md-3" style="text-align: center;" >
								<img style="width: 100px;" src="images/sips.png">
					</div>
				</div>
			</div>
		</div>	
		
		<!-- main header -->
		<div class="sticky-header main-bar-wraper">
			<div class="main-bar clearfix ">
				<div class="slide-up">
					<div class="container clearfix bg-primary" style='width:100%;'>
					
						<!-- website logo -->
						<div class="logo-header mostion"><a href="index.php"><img src="https://princecollegesikar.com/images/college.png" style="width:50%; " alt=""></a></div>
						
						<!-- nav toggle button -->
						<button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						
						<!-- main nav -->
				<div class="header-nav navbar-collapse collapse">
					<ul class=" nav navbar-nav">
						<li ><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i> Home<i class="fa fa-chevron-down"></i></a></li>
						<li> <a href="index.html#"> <i class="fa fa-university" aria-hidden="true"></i> About Us<i class="fa fa-chevron-down"></i></a>
							<ul class="sub-menu">
								<li> <a href="about.php">About Organization</a>
									</li>
								<li> <a href="vision.php">Vision Mission</a>
									</li>
							<!--	<li> <a href="afilation.php">Affiliation</a>
									</li>-->
									<li> <a href=""> Chairman's Desk</a>
									</li>
									<li> <a href=""> Director's Desk</a>
									</li>
									<li> <a href=""> Principal's Desk</a>
									</li>
							</ul>
						</li>
					<li> <a href="index.html#"> <i class="fa fa-user" aria-hidden="true"></i> Academic<i class="fa fa-chevron-down"></i></a>
						<ul class="sub-menu">
						<li><a href="#">Admission Procedure</a></li>
					    <!--<li><a href="apply.php">Apply Online </a></li>-->
						<!--<li><a href="ug-scholarship.php"> Ug scholarship</a></li>--> 
						<li><a href="#">Eligibility Criteria</a></li>
						<!--<li><a href="rules.php">Rules And Regulation </a></li>-->
						<li><a href="#">Fee Details </a></li>
					<!--<li><a href="teaching-staff.php">Teaching Staff </a></li>
						<li><a href="student-stat.php">Student Statistics</a></li>
						<li><a href="noc.php">NOC </a></li>-->
						</ul>
					</li>
					<li> <a href="index.html#"> <i class="fa fa-graduation-cap" aria-hidden="true"></i> Faculty<i class="fa fa-chevron-down"></i></a>
						<ul class="sub-menu">
						<li><a href="#">Faculty of Arts</a></li>
						<!-- <li><a href="f-sci.php">Faculty of Science </a></li> -->
						<li><a href="#">Faculty of Commerce</a></li>
						</ul>
					</li>
					<li><a href="index.html#"> <i class="fa fa-tasks" aria-hidden="true"></i> Facilities<i class="fa fa-chevron-down"></i></a>
						<ul class="sub-menu">
						<li><a href="#"> Laboratories</a></li>
						<li><a href="#">Library </a></li>
						<li><a href="#">Hostel</a></li>
						<li><a href="#">Smart Classes</a></li>
						<li><a href="#">Auditorium</a></li>
						<li><a href="#">Computer Lab</a></li>
						<li><a href="#">Transportation</a></li>
						<li><a href="#">Canteen</a></li>
						</ul>
					</li>
					<!-- <li><a href="index.html#"> <i class="fa fa-tasks" aria-hidden="true"></i> Syllabus<i class="fa fa-chevron-down"></i></a>
							<!-- <ul class="sub-menu">
							<li><a href="ias-pre.php"> IAS - Pre </a></li>
							<li><a href="ias-main.php"> IAS - Main</a></li>
							<li><a href="ras-pre.php"> RAS - Pre</a></li>
							<li><a href="ras-main.php"> RAS - Main</a></li>
							<li><a href="ssc-cgl.php"> SSC - CGL</a></li>
							<li><a href="ssc-si.php"> SSC SI & ASI Exam</a></li>
							<li><a href="patwari.php"> Patwari</a></li>
							</ul> -->
					</li> -->
					<!-- <li><a href="result.php"><i class="fa fa-graduation-cap" aria-hidden="true"></i> Result<i class="fa fa-chevron-down"></i></a></li> -->
					<!-- <li><a href="photo-g.php"><i class="fa fa-file-image-o" aria-hidden="true"></i> Gallery<i class="fa fa-chevron-down"></i></a></li> -->
					<li><a href="contact-address.php"><i class="fa fa-phone-square" aria-hidden="true"></i> Contact<i class="fa fa-chevron-down"></i></a></li>
					</ul>
				</div>
					</div>
				</div>	
			</div>
		</div>
		<!-- main header END -->
	</header>    <!-- Content -->