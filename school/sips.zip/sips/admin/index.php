<html>
    <head>
        <script>
            document.location.href = "/sips/adminLogin";
        </script>
    </head>
</html>