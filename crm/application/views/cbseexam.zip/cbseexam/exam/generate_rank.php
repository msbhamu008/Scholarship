<?php $this->load->view('layout/cbseexam_css.php'); ?>
  <div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-bus"></i> <?php echo $this->lang->line('transport'); ?></h1>
    </section>
    <!-- Main content -->
    <section class="content">
             <?php $this->load->view('cbseexam/exam/_generate_rank'); ?>

</div>   
</div>  
</section>
</div>